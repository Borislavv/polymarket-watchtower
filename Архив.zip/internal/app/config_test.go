package app

import (
	"strings"
	"testing"
	"time"

	"github.com/Borislavv/polymarket-watchtower/internal/app/usecase/category"
)

func categoryFilter(blacklist []string) *category.Filter { return category.NewFilter(blacklist) }

func loadConfigWithEnv(t *testing.T, env map[string]string) (*Config, error) {
	t.Helper()
	keys := []string{
		"APP_ENV", "LOG_LEVEL", "METRICS_PORT", "SHUTDOWN_GRACE_PERIOD",
		"POSTGRES_DSN", "POSTGRES_MAX_OPEN_CONNS", "POSTGRES_MAX_IDLE_CONNS",
		"POSTGRES_CONN_MAX_LIFETIME", "POSTGRES_AUTO_MIGRATE",
		"GAMMA_API_URL", "DATA_API_URL", "CLOB_API_URL",
		"POLYMARKET_HTTP_TIMEOUT", "POLYMARKET_USER_AGENT", "POLYMARKET_PUBLIC_BASE_URL",
		"RL_GAMMA_PER_SEC", "RL_GAMMA_BURST", "RL_DATAAPI_PER_SEC", "RL_DATAAPI_BURST",
		"DISCOVER_INTERVAL", "COLLECT_INTERVAL", "DISCOVERY_SAFETY_MAX_MARKETS", "ACTIVE_ONLY",
		"DISCOVER_ORDER", "COLLECT_CONCURRENCY", "COLLECT_BOOTSTRAP_LOOKBACK",
		"ALERT_INFO_MIN_NOTIONAL_USD", "ALERT_INFO_MIN_ODDS", "ALERT_INFO_MIN_MULTIPLIER",
		"ALERT_WARNING_MIN_NOTIONAL_USD", "ALERT_WARNING_MIN_ODDS", "ALERT_WARNING_MIN_MULTIPLIER",
		"ALERT_CRITICAL_MIN_NOTIONAL_USD", "ALERT_CRITICAL_MIN_ODDS", "ALERT_CRITICAL_MIN_MULTIPLIER",
		"SINGLE_MIN_BASELINE_TRADES", "SINGLE_MIN_BASELINE_NOTIONAL_USD",
		"BASELINE_WINDOW", "BASELINE_MIN_READY_WINDOW",
		"LIFECYCLE_ALERT_FROM_PCT", "LIFECYCLE_HOT_FROM_PCT",
		"MARKET_MIN_AGE",
		"CLUSTER_WINDOW", "CLUSTER_MIN_ANOMALOUS_TRADES",
		"CLUSTER_MIN_UNIQUE_TRADERS", "CLUSTER_MIN_TOTAL_NOTIONAL_USD",
		"CLUSTER_COOLDOWN",
		"VOLUME_MULTIPLIERS", "VOLUME_MIN_NOTIONAL_USD", "VOLUME_MIN_TRADES", "VOLUME_COOLDOWN",
		"CATEGORY_WHITELIST",
		"ALERT_WEBHOOK_URL",
		"TELEGRAM_ENABLED", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID",
		"TELEGRAM_BASE_URL", "TELEGRAM_TIMEOUT",
		"GRAFANA_BASE_URL", "GRAFANA_DASH_UID", "GRAFANA_CONTEXT_WINDOW",
	}
	for _, k := range keys {
		t.Setenv(k, "")
	}
	for k, v := range env {
		t.Setenv(k, v)
	}
	return LoadConfig()
}

func TestConfigDefaults(t *testing.T) {
	cfg, err := loadConfigWithEnv(t, nil)
	if err != nil {
		t.Fatalf("LoadConfig: %v", err)
	}
	if cfg.Anomaly.InfoMinNotionalUSD != 10_000 || cfg.Anomaly.InfoMinOdds != 3 || cfg.Anomaly.InfoMinMultiplier != 100 {
		t.Errorf("info tier defaults: notional=%v odds=%v mul=%v",
			cfg.Anomaly.InfoMinNotionalUSD, cfg.Anomaly.InfoMinOdds, cfg.Anomaly.InfoMinMultiplier)
	}
	if cfg.Anomaly.WarningMinNotionalUSD != 25_000 || cfg.Anomaly.WarningMinOdds != 5 || cfg.Anomaly.WarningMinMultiplier != 1_000 {
		t.Errorf("warning tier defaults: notional=%v odds=%v mul=%v",
			cfg.Anomaly.WarningMinNotionalUSD, cfg.Anomaly.WarningMinOdds, cfg.Anomaly.WarningMinMultiplier)
	}
	if cfg.Anomaly.CriticalMinNotionalUSD != 100_000 || cfg.Anomaly.CriticalMinOdds != 8 || cfg.Anomaly.CriticalMinMultiplier != 10_000 {
		t.Errorf("critical tier defaults: notional=%v odds=%v mul=%v",
			cfg.Anomaly.CriticalMinNotionalUSD, cfg.Anomaly.CriticalMinOdds, cfg.Anomaly.CriticalMinMultiplier)
	}
	if cfg.Anomaly.SingleMinBaselineTrades != 20 {
		t.Errorf("baseline trade-count gate: %d", cfg.Anomaly.SingleMinBaselineTrades)
	}
	if cfg.Anomaly.SingleMinBaselineNotionalUSD != 1_000 {
		t.Errorf("baseline notional gate: %v", cfg.Anomaly.SingleMinBaselineNotionalUSD)
	}
	if cfg.Anomaly.ClusterWindow != 30*time.Minute {
		t.Errorf("cluster window: %s", cfg.Anomaly.ClusterWindow)
	}
}

func TestConfigEnvOverrides(t *testing.T) {
	cfg, err := loadConfigWithEnv(t, map[string]string{
		"ALERT_INFO_MIN_NOTIONAL_USD":   "1000",
		"ALERT_CRITICAL_MIN_MULTIPLIER": "5000",
		"SINGLE_MIN_BASELINE_TRADES":    "50",
		"CLUSTER_MIN_UNIQUE_TRADERS":    "5",
	})
	if err != nil {
		t.Fatalf("LoadConfig: %v", err)
	}
	if cfg.Anomaly.InfoMinNotionalUSD != 1_000 {
		t.Errorf("info notional override: %v", cfg.Anomaly.InfoMinNotionalUSD)
	}
	if cfg.Anomaly.CriticalMinMultiplier != 5_000 {
		t.Errorf("critical mul override: %v", cfg.Anomaly.CriticalMinMultiplier)
	}
	if cfg.Anomaly.SingleMinBaselineTrades != 50 {
		t.Errorf("baseline trade-count override: %d", cfg.Anomaly.SingleMinBaselineTrades)
	}
	if cfg.Anomaly.ClusterMinWallets != 5 {
		t.Errorf("cluster wallets: %d", cfg.Anomaly.ClusterMinWallets)
	}
}

func TestConfigRejectsInvalidOdds(t *testing.T) {
	if _, err := loadConfigWithEnv(t, map[string]string{"ALERT_INFO_MIN_ODDS": "0.5"}); err == nil {
		t.Fatal("expected validation error for odds < 1")
	}
}

// TestConfigCategoryWhitelistDefault pins the shipped default: monitor only
// Politics. Narrow on purpose — operators add categories explicitly rather
// than discovering them implicitly via blacklist gaps.
func TestConfigCategoryWhitelistDefault(t *testing.T) {
	cfg, err := loadConfigWithEnv(t, nil)
	if err != nil {
		t.Fatalf("LoadConfig: %v", err)
	}
	want := []string{"Politics"}
	if len(cfg.CategoryFilter.Whitelist) != len(want) || cfg.CategoryFilter.Whitelist[0] != want[0] {
		t.Fatalf("default whitelist: got %v want %v", cfg.CategoryFilter.Whitelist, want)
	}
	// And the filter built from that default actually admits Politics
	// and rejects the common noise categories.
	f := categoryFilter(cfg.CategoryFilter.Whitelist)
	if !f.Allowed("politics", "Politics") {
		t.Error("default whitelist must admit Politics")
	}
	for _, c := range []string{"Sports", "Crypto", "Culture", "Weather", "NBA"} {
		if f.Allowed("", c) {
			t.Errorf("default whitelist must reject %q", c)
		}
	}
}

// TestConfigCategoryWhitelistOverride confirms that comma-separated env
// values parse into multiple whitelist tokens. Whitespace around each
// token is trimmed by the filter so operators can format the env line
// naturally.
func TestConfigCategoryWhitelistOverride(t *testing.T) {
	cfg, err := loadConfigWithEnv(t, map[string]string{
		"CATEGORY_WHITELIST": "Politics, Macro",
	})
	if err != nil {
		t.Fatalf("LoadConfig: %v", err)
	}
	f := categoryFilter(cfg.CategoryFilter.Whitelist)
	if !f.Allowed("politics", "Politics") || !f.Allowed("macro", "Macro") {
		t.Error("multi-token whitelist must admit each listed category")
	}
	if f.Allowed("", "Weather") {
		t.Error("category not in whitelist must be blocked")
	}
}

// TestConfigRejectsLegacyEnvVars pins the v4 cleanup contract: env vars
// from the removed in-memory aggregate engine and the deleted volume
// mode must not appear in production configuration. The presence of any
// of these strings in .env / .env.example would be silently ignored by
// the binary — better to flag them via the dedicated PRESETSHaveNoRemovedEnvVars
// test (see preset_test.go) so operators notice.
//
// Functionally the env loader ignores unknown variables, so this test
// just documents the removal — see CLAUDE.md and doc/architecture.md
// for the v4 cleanup migration notes.
func TestConfigLegacyEnvVarsAreIgnored(t *testing.T) {
	cfg, err := loadConfigWithEnv(t, map[string]string{
		"ANOMALY_MODE":         "volume",
		"AGG_BUCKET":           "5m",
		"AGG_BASELINE_WINDOW":  "1h",
		"AGG_RECENT_WINDOWS":   "1h",
		"BASELINE_MAX_SAMPLES": "999",
		"MAX_MARKETS":          "10",
		"VOLUME_MULTIPLIERS":   "1,2,3",
	})
	if err != nil {
		t.Fatalf("legacy env vars should be ignored, not rejected: %v", err)
	}
	// Same as defaults; nothing leaked.
	if cfg.Pipeline.DiscoverySafetyMaxMarkets != 0 {
		t.Errorf("safety cap default: got %d want 0", cfg.Pipeline.DiscoverySafetyMaxMarkets)
	}
}

func TestConfigRejectsInvalidEnv(t *testing.T) {
	if _, err := loadConfigWithEnv(t, map[string]string{"APP_ENV": "staging"}); err == nil {
		t.Fatal("expected error for APP_ENV=staging")
	}
}

func TestConfigRejectsInvalidPort(t *testing.T) {
	if _, err := loadConfigWithEnv(t, map[string]string{"METRICS_PORT": "0"}); err == nil {
		t.Fatal("expected error for METRICS_PORT=0")
	}
}

func TestConfigRejectsBadURL(t *testing.T) {
	if _, err := loadConfigWithEnv(t, map[string]string{"GAMMA_API_URL": "not-a-url"}); err == nil {
		t.Fatal("expected error for bad URL")
	}
}

// TestValidateInvariants_WSSafetyBelts pins the v10.6 cross-field
// rules on WebSocketConfig. The struct-tag validator alone can't
// express "MaxTokens must be >= MaxMarkets" or "MaxMarkets > 250
// requires AllowLargeSubscription", so these live in
// Config.validateInvariants().
func TestValidateInvariants_WSSafetyBelts(t *testing.T) {
	tests := []struct {
		name    string
		mutate  func(*Config)
		wantErr string
	}{
		{
			name: "happy path 25 markets / 50 tokens",
			mutate: func(c *Config) {
				c.WS.Enabled = true
				c.WS.MaxMarkets = 25
				c.WS.MaxTokens = 50
			},
			wantErr: "",
		},
		{
			name: "ws disabled bypasses every belt",
			mutate: func(c *Config) {
				c.WS.Enabled = false
				c.WS.MaxMarkets = 0
				c.WS.MaxTokens = 0
			},
			wantErr: "",
		},
		{
			name: "max_tokens < max_markets fails",
			mutate: func(c *Config) {
				c.WS.Enabled = true
				c.WS.MaxMarkets = 25
				c.WS.MaxTokens = 10
			},
			wantErr: "WS_MAX_TOKENS",
		},
		{
			name: "ws enabled with zero max_markets fails",
			mutate: func(c *Config) {
				c.WS.Enabled = true
				c.WS.MaxMarkets = 0
				c.WS.MaxTokens = 100
			},
			wantErr: "WS_MAX_MARKETS > 0",
		},
		{
			name: "large subscription without override flag fails",
			mutate: func(c *Config) {
				c.WS.Enabled = true
				c.WS.MaxMarkets = 2500
				c.WS.MaxTokens = 5000
				c.WS.AllowLargeSubscription = false
			},
			wantErr: "WS_ALLOW_LARGE_SUBSCRIPTION",
		},
		{
			name: "large subscription with override flag passes",
			mutate: func(c *Config) {
				c.WS.Enabled = true
				c.WS.MaxMarkets = 2500
				c.WS.MaxTokens = 5000
				c.WS.AllowLargeSubscription = true
			},
			wantErr: "",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cfg := &Config{}
			tt.mutate(cfg)
			err := cfg.validateInvariants()
			if tt.wantErr == "" {
				if err != nil {
					t.Errorf("expected nil err, got %v", err)
				}
				return
			}
			if err == nil {
				t.Fatalf("expected error containing %q, got nil", tt.wantErr)
			}
			if !strings.Contains(err.Error(), tt.wantErr) {
				t.Errorf("error %q does not contain %q", err.Error(), tt.wantErr)
			}
		})
	}
}
