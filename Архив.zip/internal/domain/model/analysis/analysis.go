// Package analysis defines the request/response types and the
// Analyzer interface that decouple the AI provider (OpenAI etc.)
// from the usecase layer. No OpenAI DTO leakage past this boundary.
//
// Three analyzer entry points:
//
//   - AnalyzeAlert      — one alert → one analyst note
//   - AnalyzeMarketReport — top-N candidate markets → 2h report
//   - AnalyzeOutcome    — a resolved alert → postmortem
//
// The service operates without an AI key: a noop Analyzer
// implementation (returns Status="skipped" with no text) keeps every
// downstream call path defined and the binary functional.
package analysis

import (
	"context"
	"time"
)

// Status names the analyzer's outcome. Persisted alongside the text
// so an operator can distinguish "analysis suppressed by policy"
// from "model raised an error".
type Status string

const (
	StatusOK      Status = "ok"
	StatusSkipped Status = "skipped"
	StatusError   Status = "error"
)

// --- Alert analysis -------------------------------------------------------

// AlertAnalysisRequest is the structured context the prompt builder
// receives. The fields are intentionally narrow and English-keyed so
// the prompt is small and predictable.
type AlertAnalysisRequest struct {
	// Identity
	AlertID  int64
	Kind     string // "trade_anomaly" | "accumulation" | "stable_favorite" | ...
	Severity string // info | warning | critical | hard
	Reason   string // canonical alert reason

	// Market context
	Title        string
	Category     string
	OutcomeLabel string
	LifecyclePct float64
	EndsAt       time.Time
	NowAt        time.Time

	// Trade / position numbers (zero when not applicable)
	Side               string
	NotionalUSD        float64
	Price              float64
	Odds               float64
	ProfitIfWinUSD     float64
	RemainingReturnPct float64
	Score              float64
	Confidence         float64

	// Structured reason codes — the model gets these verbatim so it
	// doesn't have to guess the firing shape.
	Reasons []string

	// Optional auxiliary context — empty when not available. The
	// prompt builder elides empty fields rather than printing zeros.
	MarketP95Ratio   float64
	TraderP95Ratio   float64
	AccumulationNote string // human-readable accumulation summary
	OwnershipNote    string
	QuietMarketNote  string
	NewWalletNote    string
	OutcomeStatus    string

	// v8 cross-flow context: when the same market has had multiple
	// alerts in the last 24h, the model needs to distinguish a
	// clean one-sided whale signal from conflicting flow. The
	// detector populates these from recent rows in polymarket_alerts.
	SameMarketRecentAlerts            int     // count last 24h
	SameMarketSameSideNotionalUSD     float64 // notional summed on this side
	SameMarketOppositeSideNotionalUSD float64 // notional summed on opposite side
	SameWalletBidirectional           bool    // wallet bought AND sold same outcome inside window

	// NoveltyOrMemeGuess flags markets the detector or operator
	// classified as joke/novelty (low informational value). When
	// true the prompt asks the model to bias toward Avoid/Watch.
	NoveltyOrMemeGuess bool

	// PublicContextEnabled tells the model whether web_search was
	// run for this request. When false the model must include a
	// "Live context was not checked." sentence in Risk or Next so
	// the operator never confuses an offline note with a researched one.
	PublicContextEnabled bool

	// EventNarrativeContext is the rendered Polymarket event-page
	// narrative block (event metadata + event markets + chart
	// annotations). Sourced from
	// internal/app/usecase/eventpagecontext.Provider, which fetches
	// the hydrated /event/<slug>.json payload via the
	// internal/infra/polymarket/eventpage client. Empty when the
	// loader is not wired OR the slug could not be resolved OR the
	// fetch failed — the prompt then renders an "unavailable" slot
	// and tells the model not to invent news.
	EventNarrativeContext string

	// CatalystContext is the rendered Political-Catalyst
	// Intelligence block ("Future catalysts:" prompt slot). Sourced
	// from internal/app/usecase/eventcatalyst.Provider; empty when
	// no active/expected catalysts are registered for the event.
	// Carries the catalyst_type, status, expected_at, and the
	// bullish/bearish/invalidation scenarios the AI uses to reason
	// about pre/post-catalyst flow timing.
	CatalystContext string
}

// AlertAnalysis is what the analyzer returns.
type AlertAnalysis struct {
	Status           Status
	Model            string
	AnalysisText     string
	Verdict          string // operator-facing verdict: actionable | watchlist | avoid | n/a
	PromptChars      int
	OutputChars      int
	PromptTokens     int
	CompletionTokens int
	EstimatedCostUSD float64
	LastError        string // populated when Status == error
}

// --- Outcome analysis (postmortem) ---------------------------------------

type OutcomeAnalysisRequest struct {
	AlertID      int64
	Kind         string
	Severity     string
	Title        string
	Category     string
	OutcomeLabel string

	// What the alert SAID at fire time.
	AlertText          string // the original Telegram body, escaped
	NotionalUSD        float64
	Probability        float64
	ProfitIfWinUSD     float64
	RemainingReturnPct float64
	Score              float64
	Confidence         float64
	Reasons            []string

	// What ACTUALLY happened.
	OutcomeStatus  string // resolved_correct | resolved_wrong | unknown | unavailable
	WinningOutcome string
	CLV15m         float64
	CLV1h          float64
	CLV6h          float64
	CLV24h         float64
	ResolvedAt     time.Time

	// EventNarrativeContext is the rendered Polymarket event-page
	// narrative block (annotations + event metadata + event-wide
	// market pricing) as of the resolution time. Used by the
	// postmortem to ask "did the catalyst the market priced in
	// actually happen?". Empty when the provider is not wired.
	EventNarrativeContext string
}

type OutcomeAnalysis struct {
	Status           Status
	Model            string
	ReasonText       string  // why did this resolve this way
	LessonsText      string  // future-lessons takeaway
	WonExpected      *bool   // nil = uncertain; true = Watchtower expected this; false = surprised
	Confidence       float64 // 0..1
	PromptTokens     int
	CompletionTokens int
	EstimatedCostUSD float64
	LastError        string
}

// --- Political-Catalyst extraction (v9.6) -------------------------------

// CatalystExtractionRequest is the structured prompt input the
// eventcatalyst importer hands to the AI for one event slug. The
// importer composes this from the event-page payload + recent
// Watchtower flow + existing catalyst rows; the AI returns a strict
// JSON `CatalystExtractionResponse`.
//
// All Polymarket-authored fields (annotations, event metadata) are
// DATA the AI reasons over, never instructions. The system never
// re-interprets returned strings except by JSON schema validation.
type CatalystExtractionRequest struct {
	EventSlug         string
	AnalysisTimeUTC   time.Time
	EventMetadata     CatalystEventMetadata
	Markets           []CatalystMarket
	Annotations       []CatalystAnnotation
	FlowSummary       CatalystFlowSummary
	ExistingCatalysts []CatalystExistingRow
}

// CatalystEventMetadata is the compact event header the prompt gets.
type CatalystEventMetadata struct {
	Title              string
	Description        string
	ResolutionRules    string
	Category           string
	StartDate          time.Time
	EndDate            time.Time
	ContextDescription string
	ContextUpdatedAt   time.Time
}

// CatalystMarket is one market under the event with current pricing.
type CatalystMarket struct {
	ConditionID        string
	Question           string
	GroupItemTitle     string
	Outcomes           []string
	OutcomePrices      []string
	Volume24hUSD       float64
	Liquidity          float64
	OneHourPriceChange *float64
	OneDayPriceChange  *float64
	OneWeekPriceChange *float64
	LastTradePrice     *float64
	Active             bool
	Closed             bool
	EndDate            time.Time
}

// CatalystAnnotation is one normalised annotation row passed to AI.
type CatalystAnnotation struct {
	Timestamp   time.Time
	Title       string
	Summary     string
	Outcome     string
	PriceBefore *float64
	PriceAfter  *float64
	PriceChange *float64
	SourceNames []string
}

// CatalystFlowSummary is the compact recent-flow rollup.
type CatalystFlowSummary struct {
	RecentAlertsCount       int
	StrongestSide           string
	AccumulationNote        string
	OwnershipNote           string
	ClusterNote             string
	SameSideNotional24h     float64
	OppositeSideNotional24h float64
	LargestRecentTradeUSD   float64
}

// CatalystExistingRow describes a catalyst the system already knows.
// Passed so the model can preserve / update / invalidate it instead
// of duplicating.
type CatalystExistingRow struct {
	CatalystType string
	Title        string
	ExpectedAt   time.Time
	Status       string
	Confidence   float64
}

// CatalystExtractionResponse is the strict JSON shape the model
// returns. JSON tags MUST match PART 4 schema verbatim.
type CatalystExtractionResponse struct {
	EventSlug       string              `json:"event_slug"`
	AnalysisTimeUTC string              `json:"analysis_time_utc"`
	Catalysts       []ExtractedCatalyst `json:"catalysts"`
	// Transport metadata stamped by the analyzer; not part of the
	// JSON contract.
	Status           Status  `json:"-"`
	Model            string  `json:"-"`
	PromptTokens     int     `json:"-"`
	CompletionTokens int     `json:"-"`
	EstimatedCostUSD float64 `json:"-"`
	LastError        string  `json:"-"`
}

// ExtractedCatalyst is one catalyst row from the strict JSON
// response. Nullable upstream fields use pointers so we can
// distinguish "absent" from "empty / zero".
type ExtractedCatalyst struct {
	CatalystType         string   `json:"catalyst_type"`
	Title                string   `json:"title"`
	Description          string   `json:"description"`
	ExpectedAt           *string  `json:"expected_at"`
	Confidence           float64  `json:"confidence"`
	Source               string   `json:"source"`
	SourceURL            *string  `json:"source_url"`
	Status               string   `json:"status"`
	BlockedReason        *string  `json:"blocked_reason"`
	BullishScenario      string   `json:"bullish_scenario"`
	BearishScenario      string   `json:"bearish_scenario"`
	InvalidationScenario string   `json:"invalidation_scenario"`
	FlowInterpretation   string   `json:"flow_interpretation"`
	AffectedOutcomes     []string `json:"affected_outcomes"`
}

// CatalystExtractor is the seam used by the importer. *openai.Client
// satisfies it for production; tests inject fakes. NoopExtractor
// returns an empty response so the importer can run end-to-end
// without an AI key (it will skip the upsert path).
type CatalystExtractor interface {
	ExtractCatalysts(ctx context.Context, req CatalystExtractionRequest) (CatalystExtractionResponse, error)
}

// NoopExtractor returns an empty StatusSkipped response.
type NoopExtractor struct{}

func (NoopExtractor) ExtractCatalysts(_ context.Context, req CatalystExtractionRequest) (CatalystExtractionResponse, error) {
	return CatalystExtractionResponse{
		EventSlug:       req.EventSlug,
		AnalysisTimeUTC: req.AnalysisTimeUTC.UTC().Format(time.RFC3339),
		Catalysts:       nil,
		Status:          StatusSkipped,
		Model:           "noop",
	}, nil
}

// --- Analyzer interface ---------------------------------------------------

// Analyzer is the single seam between the AI provider and the rest
// of the system. *openai.Client and *noop.Analyzer both satisfy it.
// v11.2: AnalyzeMarketReport removed with the 2h market intelligence
// surface; only the alert + outcome paths remain.
type Analyzer interface {
	AnalyzeAlert(ctx context.Context, req AlertAnalysisRequest) (AlertAnalysis, error)
	AnalyzeOutcome(ctx context.Context, req OutcomeAnalysisRequest) (OutcomeAnalysis, error)
}

// NoopAnalyzer satisfies Analyzer when the operator has not wired an
// OpenAI key. Every call returns StatusSkipped with empty text — the
// usecase layer renders the "AI analysis disabled" path cleanly.
type NoopAnalyzer struct{}

func (NoopAnalyzer) AnalyzeAlert(_ context.Context, _ AlertAnalysisRequest) (AlertAnalysis, error) {
	return AlertAnalysis{Status: StatusSkipped, Model: "noop"}, nil
}
func (NoopAnalyzer) AnalyzeOutcome(_ context.Context, _ OutcomeAnalysisRequest) (OutcomeAnalysis, error) {
	return OutcomeAnalysis{Status: StatusSkipped, Model: "noop"}, nil
}
